<template>
  <div class="">
    <slot></slot>
  </div>
</template>

<script></script>

<style scoped>
div {
  /* border-radius: 15px; */
  background-color: var(--secondaryBtn);
  padding:25px;
  font-size: 48px;
  color: var(--accent);
  font-weight: bold;
  width: 100%;
  border: 1px solid var(--primary);
}
</style>
<template>
  <div>
  <left-panel></left-panel>
  <h1>Page Not Found</h1>
</div>
</template>

<script>
import LeftPanel from '@/components/base/LeftPanel.vue';

export default {
  components:{
  LeftPanel
  }
}
</script>
<style scoped>
</style>
